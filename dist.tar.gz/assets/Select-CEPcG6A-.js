import{j as r,x as l}from"./index-DKOolI9D.js";const i=({label:a,id:o,options:d,containerClassName:t="",className:n="",...s})=>r.jsxs("div",{className:`w-full ${t}`,children:[a&&r.jsx("label",{htmlFor:o,className:"block text-sm font-medium text-foreground dark:text-dark-foreground mb-1.5",children:a}),r.jsxs("div",{className:"relative",children:[r.jsx("select",{id:o,className:`appearance-none flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 pr-8 text-sm text-foreground
                     ring-offset-background dark:ring-offset-dark-background 
                     focus:outline-none focus:ring-2 focus:ring-ring dark:focus:ring-dark-ring focus:ring-offset-2 
                     disabled:cursor-not-allowed disabled:opacity-50 
                     dark:bg-dark-input dark:border-dark-border dark:text-dark-foreground
                     transition-all duration-150 ease-in-out
                     ${n}`,...s,children:d.map(e=>r.jsx("option",{value:e.value,className:"dark:bg-dark-input dark:text-dark-foreground",children:e.label},e.value))}),r.jsx(l,{className:"absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground dark:text-dark-muted-foreground pointer-events-none"})]})]});export{i as S};
